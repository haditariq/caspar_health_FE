const Icons = {
  goBack: '/icons/back-arrow.png',
  search: '/icons/search.png',
  accending: '/icons/sort-accend.png',
  decending: '/icons/sort-decend.png',
  cross: '/icons/cross.png',
  link: '/icons/link.png',
  alert: '/icons/black_alert.png'
}


export default Icons;