import React from 'react';

const PatientFeedItem = () => {
  return <div>hello item</div>;
};

export default PatientFeedItem;
